package v4;

public class FlyRocketPowered implements FlyBehavior
{
    // instance variables - replace the example below with your own
     public void fly(){
        System.out.println("I'm flying with a rocket");
    }
}
