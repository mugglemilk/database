package v3;

public class RedheadDuck extends Duck implements Quacktable
{
  void  display(){
      //looks like a method
    }

    void quack(){}
}
