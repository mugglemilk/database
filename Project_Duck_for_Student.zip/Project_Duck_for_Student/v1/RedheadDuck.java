package v1;

public class RedheadDuck extends Duck
{
  void  display(){
      //looks like a method
    }
}
