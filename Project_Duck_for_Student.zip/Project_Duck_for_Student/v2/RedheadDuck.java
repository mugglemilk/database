package v2;

public class RedheadDuck extends Duck
{
  void  display(){
      //looks like a method
    }
}
