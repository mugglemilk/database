package v2;

public class DecayDuck extends Duck
{
  void quak(){
    //override to do nothing
   }
  void display(){// decay duck
    }
  void fly(){//over to do nothing
    }
}
