package v3;


public interface Flyable
{
   void fly();
}
