package v3;


public interface Quacktable
{
    void quack();
}
