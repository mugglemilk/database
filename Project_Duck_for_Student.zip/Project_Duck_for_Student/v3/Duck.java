package v3;

class Duck
{
   void quack(){}
   void swim(){}
   void display(){}
   void fly(){} // By putting flu() in the superclass, he gave flying ability to All ducks including these that shouldn't
   //other duck-like method...
}
