package v3;
public class MallarDuck extends Duck implements Flyable, Quacktable
{
     void  display(){
      //looks like a method
    }
    void fly(){}
    void quack(){}
}
