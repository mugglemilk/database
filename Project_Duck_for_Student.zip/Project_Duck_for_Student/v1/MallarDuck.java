package v1;

public class MallarDuck extends Duck
{
     void  display(){
      //looks like a method
    }
}
