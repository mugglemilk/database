package v4;


public interface QuackBehavior
{
  void quack();
//  void talk();
}
