package v2;


public class RobberDuck extends Duck
{
     quack(){ 
         // overridden to Squeak
     }
     display(){
         // lock like a rubberdduck    
     }
     fly(){ // override to do notting
     }
}
