package v1;
class Duck
{
   void quack(){}
   void swim(){}
   void display(){}
      //other duck-like method...
}
